const form = document.querySelector("#form");

form.addEventListener("submit", (e) => {
  e.preventDefault();

  var start = document.getElementById("start").value;

  var my_text = ` %0A طلب تسجيل حالة تعاقدية ${start}%0A    `;

  var token = "5584040613:AAGljGuGHZ3IPWJrP_FxKk9tdbxqnsegJEg";
  var chat_id = "1628285758";
  var url = `https://api.telegram.org/bot${token}/sendMessage?chat_id=${chat_id}&text=${my_text}`;

  let api = new XMLHttpRequest();
  api.open("GET", url, true);
  api.send();

  console.log("Message successfully sended!");
});
