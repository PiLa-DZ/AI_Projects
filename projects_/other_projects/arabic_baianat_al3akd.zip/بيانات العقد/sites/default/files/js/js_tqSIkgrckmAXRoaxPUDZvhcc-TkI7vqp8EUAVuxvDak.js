jQuery('.a-gmapfield input').focus(function() { jQuery(this).blur(); });

// Since the value of latitude and longitude does not trigger the
// change event. We have to watch the field when it is changed.
ejar_contract_request_customWatchField('.gmapfield .gmap-locpick_latitude', function(){
  var latitude = jQuery('.gmapfield .gmap-locpick_latitude').val();
  var longitude = jQuery('.gmapfield .gmap-locpick_longitude').val();

  jQuery.ajax({
    url: 'https://maps.googleapis.com/maps/api/geocode/json?key=AIzaSyBePpoM0AwHV4qhYaQYFkO_jrjy6NoKGbk&language=ar&region=SA&latlng=' + latitude + ',' + longitude,
    // contentType: json,
    processData: false,
    success: function (result) {
      // Fill fields.
      if (!ejar_contract_request_customGetLocationItem(result.results[0].address_components, 'street_number')) {
        jQuery('.gmapfield .form-item-location-building-number input').val(ejar_contract_request_customGetLocationItem(result.results[0].address_components, 'premise'));
      } else {
        jQuery('.gmapfield .form-item-location-building-number input').val(ejar_contract_request_customGetLocationItem(result.results[0].address_components, 'street_number'));
      }
      jQuery('.gmapfield .form-item-location-street input').val(ejar_contract_request_customGetLocationItem(result.results[0].address_components, 'route'));
      jQuery('.gmapfield .form-item-location-district-name input').val(ejar_contract_request_customGetLocationItem(result.results[0].address_components, 'sublocality_level_1'));
      jQuery('.gmapfield .form-item-location-postal-code input').val(ejar_contract_request_customGetLocationItem(result.results[0].address_components, 'postal_code'));
      jQuery('.gmapfield .form-item-location-postal-code-suffix input').val(ejar_contract_request_customGetLocationItem(result.results[0].address_components, 'postal_code_suffix'));
      jQuery('.gmapfield .form-item-location-city input').val(ejar_contract_request_customGetLocationItem(result.results[0].address_components, 'locality'));
      jQuery('.gmapfield .form-item-location-full-address input').val(result.results[0].formatted_address);

    }, error: function (result) {
      // onsole.log('err', result);
    }
  });
});

function ejar_contract_request_customWatchField(selector, callback) {
  var input = jQuery(selector);
  var oldvalue = input.val();
  setInterval(function(){
    if (input.val()!=oldvalue){
      oldvalue = input.val();
      callback();
    }
  }, 100);
};

// This function has been copied from subdivision form.
function ejar_contract_request_customGetLocationItem (object, key) {
  for (var i = 0; i < object.length; i++) {
    var typesList = object[i].types;
    for (var j = 0; j < typesList.length; j++) {
      if (typesList[j] == key) {
        return object[i].long_name;
      }
    }
  }
};
;
